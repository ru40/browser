This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.

**Used open source libraries:**

_android-file-chooser_
https://github.com/hedzr/android-file-chooser

_Android-ObservableScrollView_
https://github.com/ksoichiro/Android-ObservableScrollView

_browser_
https://github.com/yoshihiroando/browser

_encrypted-userprefs_
https://github.com/sveinungkb/encrypted-userprefs